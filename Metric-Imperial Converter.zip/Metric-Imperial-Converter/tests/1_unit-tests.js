const chai = require('chai');
let assert = chai.assert;
const ConvertHandler = require('../controllers/convertHandler.js');

let convertHandler = new ConvertHandler();

suite('Unit Tests', function() {

  suite('Function getNum(input)', function() {
    test('should correctly read a whole number input', function() {
      assert.strictEqual(convertHandler.getNum('32L'), 32);
    });

    test('should correctly read a decimal number input', function() {
      assert.strictEqual(convertHandler.getNum('3.1mi'), 3.1);
    });

    test('should correctly read a fractional input', function() {
      assert.strictEqual(convertHandler.getNum('1/2kg'), 0.5);
    });

    test('should correctly read a fractional input with a decimal', function() {
      assert.strictEqual(convertHandler.getNum('2.5/5lbs'), 0.5);
    });

    test('should correctly return an error on a double-fraction', function() {
      assert.strictEqual(convertHandler.getNum('3/2/3km'), 'invalid number');
    });

    test('should correctly default to a numerical input of 1 when no numerical input is provided', function() {
      assert.strictEqual(convertHandler.getNum('kg'), 1);
    });
  });

  suite('Function getUnit(input)', function() {
    test('should correctly read each valid input unit (case-insensitive)', function() {
      const inputs   = ['gal','L','mi','KM','lBs','KG'];
      const expected = ['gal','L','mi','km','lbs','kg'];
      inputs.forEach((unit, i) => {
        assert.strictEqual(convertHandler.getUnit('10' + unit), expected[i]);
      });
    });

    test('should correctly return an error for an invalid input unit', function() {
      assert.strictEqual(convertHandler.getUnit('32g'), 'invalid unit');
    });
  });

  suite('Function getReturnUnit(initUnit)', function() {
    test('should return the correct return unit for each valid input unit', function() {
      const inputUnits  = ['gal','L','mi','km','lbs','kg'];
      const returnUnits = ['L','gal','km','mi','kg','lbs'];
      inputUnits.forEach((u, i) => {
        assert.strictEqual(convertHandler.getReturnUnit(u), returnUnits[i]);
      });
    });
  });

  suite('Function spellOutUnit(unit)', function() {
    test('should correctly return the spelled-out string unit for each valid input unit', function() {
      const units     = ['gal','L','mi','km','lbs','kg'];
      const fullNames = ['gallons','liters','miles','kilometers','pounds','kilograms'];
      units.forEach((u, i) => {
        assert.strictEqual(convertHandler.spellOutUnit(u), fullNames[i]);
      });
    });
  });

  suite('Function convert(num, unit)', function() {
    test('should correctly convert gal to L', function() {
      const result   = convertHandler.convert(1, 'gal');
      const expected = 3.78541;
      assert.approximately(result, expected, 0.00001);
    });

    test('should correctly convert L to gal', function() {
      const result   = convertHandler.convert(1, 'L');
      const expected = 1 / 3.78541;
      assert.approximately(result, expected, 0.00001);
    });

    test('should correctly convert mi to km', function() {
      const result   = convertHandler.convert(1, 'mi');
      const expected = 1.60934;
      assert.approximately(result, expected, 0.00001);
    });

    test('should correctly convert km to mi', function() {
      const result   = convertHandler.convert(1, 'km');
      const expected = 1 / 1.60934;
      assert.approximately(result, expected, 0.00001);
    });

    test('should correctly convert lbs to kg', function() {
      const result   = convertHandler.convert(1, 'lbs');
      const expected = 0.453592;
      assert.approximately(result, expected, 0.00001);
    });

    test('should correctly convert kg to lbs', function() {
      const result   = convertHandler.convert(1, 'kg');
      const expected = 1 / 0.453592;
      assert.approximately(result, expected, 0.00001);
    });
  });

});
