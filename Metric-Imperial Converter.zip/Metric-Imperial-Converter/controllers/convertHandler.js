function ConvertHandler() {

  // Parse and validate the numeric part of the input
  this.getNum = function(input) {
    // find where the unit starts (first letter index)
    const match = input.match(/[a-zA-Z]/);
    const idx = match ? match.index : input.length;
    const numStr = input.slice(0, idx).trim();

    // default to 1 if no numeric part
    if (!numStr) return 1;

    // invalid if more than one slash
    if ((numStr.match(/\//g) || []).length > 1) return 'invalid number';

    let result;
    if (numStr.includes('/')) {
      const [numerator, denominator] = numStr.split('/');
      const num = parseFloat(numerator);
      const den = parseFloat(denominator);
      result = den === 0 ? NaN : num / den;
    } else {
      result = parseFloat(numStr);
    }

    return isNaN(result) ? 'invalid number' : result;
  };

  // Parse and validate the unit part of the input
  this.getUnit = function(input) {
    const match = input.match(/[a-zA-Z]/);
    const idx = match ? match.index : input.length;
    const unit = input.slice(idx).trim().toLowerCase();

    switch (unit) {
      case 'gal':
        return 'gal';
      case 'l':
        return 'L';
      case 'mi':
        return 'mi';
      case 'km':
        return 'km';
      case 'lbs':
        return 'lbs';
      case 'kg':
        return 'kg';
      default:
        return 'invalid unit';
    }
  };

  // Map each valid unit to its conversion counterpart
  this.getReturnUnit = function(initUnit) {
    const unitMap = {
      gal: 'L',
      L:   'gal',
      mi:  'km',
      km:  'mi',
      lbs: 'kg',
      kg:  'lbs'
    };
    return unitMap[initUnit];
  };

  // Spell out the full name of each unit
  this.spellOutUnit = function(unit) {
    const spellMap = {
      gal: 'gallons',
      L:   'liters',
      mi:  'miles',
      km:  'kilometers',
      lbs: 'pounds',
      kg:  'kilograms'
    };
    return spellMap[unit];
  };

  // Perform the numeric conversion
  this.convert = function(initNum, initUnit) {
    const galToL  = 3.78541;
    const lbsToKg = 0.453592;
    const miToKm  = 1.60934;
    let result;

    switch (initUnit) {
      case 'gal':
        result = initNum * galToL;
        break;
      case 'L':
        result = initNum / galToL;
        break;
      case 'lbs':
        result = initNum * lbsToKg;
        break;
      case 'kg':
        result = initNum / lbsToKg;
        break;
      case 'mi':
        result = initNum * miToKm;
        break;
      case 'km':
        result = initNum / miToKm;
        break;
      default:
        return null;
    }

    // round to 5 decimal places
    return parseFloat(result.toFixed(5));
  };

  // Build the human-readable conversion string
  this.getString = function(initNum, initUnit, returnNum, returnUnit) {
    const initUnitSpelled  = this.spellOutUnit(initUnit);
    const returnUnitSpelled = this.spellOutUnit(returnUnit);

    return `${initNum} ${initUnitSpelled} converts to ${returnNum} ${returnUnitSpelled}`;
  };

}

module.exports = ConvertHandler;