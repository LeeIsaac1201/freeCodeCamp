/* eslint-env node */

// index.js
// Where your Node application starts

require('dotenv').config()
const express = require('express')
const cors = require('cors')
const path = require('path')
const app = express()

// Middleware Configuration
app.use(cors({ optionsSuccessStatus: 200 }))
app.use(express.static('public'))

// Routes
app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname, 'views', 'index.html'))
})

app.get('/api/hello', function (req, res) {
  res.json({ greeting: 'hello API' })
})

app.get('/api/whoami', function (req, res) {
  res.json({
    ipaddress: req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress,
    language: req.headers['accept-language'],
    software: req.headers['user-agent']
  })
})

// Server Configuration
const listener = app.listen(process.env.PORT || 3000, function () {
  console.log('Your app is listening on port ' + listener.address().port)
})