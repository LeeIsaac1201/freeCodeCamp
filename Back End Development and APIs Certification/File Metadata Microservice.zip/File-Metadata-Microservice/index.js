/* eslint-env node */

// Required Dependencies
const express = require('express')
const cors = require('cors')
const multer = require('multer')
require('dotenv').config()
const path = require('path')

// Application Setup
const app = express()
const upload = multer({ dest: 'uploads/' })

// Middleware
app.use(cors())
app.use('/public', express.static(path.join(process.cwd(), 'public')))

// Root Route - Serve User Interface (UI)
app.get('/', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'views', 'index.html'))
})

// File Upload Endpoint
app.post('/api/fileanalyse', upload.single('upfile'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' })
  }

  const { originalname, mimetype, size } = req.file

  res.json({
    name: originalname,
    type: mimetype,
    size: size
  })
})

// Launch Server
const port = process.env.PORT || 3000
app.listen(port, () => {
  console.log('Your app is listening on port ' + port)
})