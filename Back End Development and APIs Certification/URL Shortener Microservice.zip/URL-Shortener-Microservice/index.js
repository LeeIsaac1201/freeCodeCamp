/* eslint-env node */

// Load environment variables from .env file (if available)
require('dotenv').config()

// Import required modules
const express = require('express')
const cors = require('cors')
const dns = require('dns')
const bodyParser = require('body-parser')

// Initialise Express application
const app = express()

// Basic Configuration
const port = process.env.PORT || 3000

app.use(cors())

// Middleware for parsing URL-encoded data in POST requests
app.use(bodyParser.urlencoded({ extended: false }))

// Serve static files from the public directory
app.use('/public', express.static(`${process.cwd()}/public`))

// Route for serving the homepage
app.get('/', function (req, res) {
  res.sendFile(process.cwd() + '/views/index.html')
})

// Your first API endpoint
app.get('/api/hello', function (req, res) {
  res.json({ greeting: 'hello API' })
})

// In-memory storage for URLs
const urlDatabase = {}
let counter = 1

// POST endpoint to shorten URLs
app.post('/api/shorturl', (req, res) => {
  const { url } = req.body

  const urlRegex = /^(https?:\/\/)(www\.)?([\w-]+\.)+[\w]{2,}(\/.*)?$/
  if (!urlRegex.test(url)) {
    return res.json({ error: 'invalid url' })
  }

  const hostname = new URL(url).hostname

  dns.lookup(hostname, (err) => {
    if (err) {
      return res.json({ error: 'invalid url' })
    }

    const shortUrl = counter++
    urlDatabase[shortUrl] = url

    res.json({ original_url: url, short_url: shortUrl })
  })
})

// GET endpoint to redirect shortened URLs
app.get('/api/shorturl/:short_url', (req, res) => {
  const shortUrl = req.params.short_url
  const originalUrl = urlDatabase[shortUrl]

  if (!originalUrl) {
    return res.json({ error: 'URL not found' })
  }

  res.redirect(originalUrl)
})

// Start server
app.listen(port, function () {
  console.log(`🚀 Listening on port ${port}`)
})