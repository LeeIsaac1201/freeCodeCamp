/* eslint-env node */

// Required Dependencies
const express = require('express')
const app = express()
const cors = require('cors')
const mongoose = require('mongoose')
require('dotenv').config()
const bodyParser = require('body-parser')
const path = require('path')

// Middleware Setup
app.use(cors())
app.use(express.static('public'))
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI)

// Define MongoDB Schemas
const userSchema = new mongoose.Schema({
  username: { type: String, required: true }
})

const exerciseSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  description: { type: String, required: true },
  duration: { type: Number, required: true },
  date: { type: Date, required: true }
})

// Create Models from Schemas
const User = mongoose.model('User', userSchema)
const Exercise = mongoose.model('Exercise', exerciseSchema)

// Root Route for UI
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'))
})

// Create a New User
app.post('/api/users', async (req, res) => {
  try {
    const user = new User({ username: req.body.username })
    await user.save()
    res.json({ username: user.username, _id: user._id })
  } catch {
    res.status(500).json({ error: 'Failed to create user' })
  }
})

// Fetch All Users
app.get('/api/users', async (req, res) => {
  const users = await User.find({}, 'username _id')
  res.json(users)
})

// Add a New Exercise
app.post('/api/users/:_id/exercises', async (req, res) => {
  const userId = req.params._id
  const { description, duration, date } = req.body

  const user = await User.findById(userId)
  if (!user) return res.status(404).json({ error: 'User not found' })

  const exercise = new Exercise({
    userId,
    description,
    duration: parseInt(duration),
    date: date ? new Date(date) : new Date()
  })

  await exercise.save()

  res.json({
    _id: user._id,
    username: user.username,
    description: exercise.description,
    duration: exercise.duration,
    date: exercise.date.toDateString()
  })
})

// Retrieve Exercise Logs
app.get('/api/users/:_id/logs', async (req, res) => {
  const { from, to, limit } = req.query
  const userId = req.params._id

  const user = await User.findById(userId)
  if (!user) return res.status(404).json({ error: 'User not found' })

  const filter = { userId }
  if (from || to) {
    filter.date = {}
    if (from) filter.date.$gte = new Date(from)
    if (to) filter.date.$lte = new Date(to)
  }

  const exercises = await Exercise.find(filter)
    .limit(parseInt(limit) || 0)
    .select('description duration date')

  const log = exercises.map(e => ({
    description: e.description,
    duration: e.duration,
    date: e.date.toDateString()
  }))

  res.json({
    _id: user._id,
    username: user.username,
    count: log.length,
    log
  })
})

// Launch Server
const listener = app.listen(process.env.PORT || 3000, () => {
  console.log('Your app is listening on port ' + listener.address().port)
})