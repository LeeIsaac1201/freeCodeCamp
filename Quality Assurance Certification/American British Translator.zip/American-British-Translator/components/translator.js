const americanOnly = require('./american-only.js');
const americanToBritishSpelling = require('./american-to-british-spelling.js');
const americanToBritishTitles = require('./american-to-british-titles.js');
const britishOnly = require('./british-only.js');

class Translator {
  constructor() {
    this.timeRegexAmerican = /\b(\d{1,2}):(\d{2})\b/g;
    this.timeRegexBritish  = /\b(\d{1,2})\.(\d{2})\b/g;
  }

  // Escape special chars in a string so RegExp() treats them literally
  escapeRegExp(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // If the original match is capitalized, capitalize the replacement too
  preserveCase(match, replacement) {
    return match[0] === match[0].toUpperCase()
      ? replacement.charAt(0).toUpperCase() + replacement.slice(1)
      : replacement;
  }

  translate(text, locale) {
    if (locale !== 'american-to-british' && locale !== 'british-to-american') {
      return { error: 'Invalid value for locale field' };
    }

    let translation = text;

    //
    // 1) TITLES / HONORIFICS
    //
    // Map either american-to-british or british-to-american (inverted)
    const titleMap = locale === 'american-to-british'
      ? americanToBritishTitles
      : Object.fromEntries(
          Object.entries(americanToBritishTitles).map(([k, v]) => [v, k])
        );

    Object.entries(titleMap).forEach(([key, val]) => {
      const escKey = this.escapeRegExp(key);
      // Only match when followed by a space or end-of-string
      const re = new RegExp(`\\b${escKey}(?=\\s|$)`, 'gi');
      translation = translation.replace(
        re,
        match => `<span class="highlight">${this.preserveCase(match, val)}</span>`
      );
    });

    //
    // 2) WORD / PHRASE & SPELLING REPLACEMENTS
    //
    // american-only  &  american-to-british-spelling  if A→B
    // british-only   &  inverted spelling map        if B→A
    const dicts = locale === 'american-to-british'
      ? [americanOnly, americanToBritishSpelling]
      : [britishOnly, Object.fromEntries(
          Object.entries(americanToBritishSpelling).map(([k,v])=>[v,k])
        )];

    dicts.forEach(dict => {
      Object.entries(dict).forEach(([word, replacement]) => {
        const escWord = this.escapeRegExp(word);
        const re = new RegExp(`\\b${escWord}\\b`, 'gi');
        translation = translation.replace(
          re,
          match => `<span class="highlight">${this.preserveCase(match, replacement)}</span>`
        );
      });
    });

    //
    // 3) TIME FORMATTING
    //
    const timeRe    = locale === 'american-to-british'
      ? this.timeRegexAmerican
      : this.timeRegexBritish;
    const timeFmt   = locale === 'american-to-british'
      ? '$1.$2'
      : '$1:$2';

    translation = translation.replace(
      timeRe,
      `<span class="highlight">${timeFmt}</span>`
    );

    //
    // 4) NO CHANGES?
    //
    if (translation === text) {
      return { text, translation: 'Everything looks good to me!' };
    }

    return { text, translation };
  }
}

module.exports = Translator;
