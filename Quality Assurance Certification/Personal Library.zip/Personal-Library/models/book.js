const mongoose = require("mongoose");
const { Schema } = mongoose;

const bookSchema = new Schema({
  title: { type: String, required: true },
  comments: { type: [String], default: [] },
});

// Virtual to expose comment count
bookSchema.virtual("commentcount").get(function () {
  return this.comments.length;
});

// Ensure virtuals are serialized
bookSchema.set("toJSON", { virtuals: true });

module.exports = mongoose.model("Book", bookSchema);
