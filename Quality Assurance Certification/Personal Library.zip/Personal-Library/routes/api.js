'use strict';

const mongoose = require('mongoose');
const Book     = require('../models/book');

module.exports = function (app) {

  app.route('/api/books')

    // GET /api/books
    .get(async (req, res) => {
      try {
        const books = await Book.find({});
        const formatted = books.map(b => ({
          _id: b._id,
          title: b.title,
          commentcount: b.commentcount
        }));
        return res.json(formatted);
      } catch (err) {
        return res.status(500).type('text').send('server error');
      }
    })

    // POST /api/books
    .post(async (req, res) => {
      const title = req.body.title;
      if (!title) {
        return res.type('text').send('missing required field title');
      }
      try {
        const newBook = new Book({ title });
        const saved  = await newBook.save();
        return res.json({ _id: saved._id, title: saved.title });
      } catch (err) {
        return res.status(500).type('text').send('server error');
      }
    })

    // DELETE /api/books
    .delete(async (req, res) => {
      try {
        await Book.deleteMany({});
        return res.type('text').send('complete delete successful');
      } catch (err) {
        return res.status(500).type('text').send('server error');
      }
    });


  app.route('/api/books/:id')

    // GET /api/books/:id
    .get(async (req, res) => {
      const bookid = req.params.id;
      if (!mongoose.Types.ObjectId.isValid(bookid)) {
        return res.type('text').send('no book exists');
      }
      try {
        const book = await Book.findById(bookid);
        if (!book) {
          return res.type('text').send('no book exists');
        }
        return res.json({
          _id: book._id,
          title: book.title,
          comments: book.comments
        });
      } catch (err) {
        return res.type('text').send('no book exists');
      }
    })

    // POST /api/books/:id
    .post(async (req, res) => {
      const bookid = req.params.id;
      const comment = req.body.comment;
      if (!comment) {
        return res.type('text').send('missing required field comment');
      }
      if (!mongoose.Types.ObjectId.isValid(bookid)) {
        return res.type('text').send('no book exists');
      }
      try {
        const book = await Book.findById(bookid);
        if (!book) {
          return res.type('text').send('no book exists');
        }
        book.comments.push(comment);
        await book.save();
        return res.json({
          _id: book._id,
          title: book.title,
          comments: book.comments
        });
      } catch (err) {
        return res.type('text').send('no book exists');
      }
    })

    // DELETE /api/books/:id
    .delete(async (req, res) => {
      const bookid = req.params.id;
      if (!mongoose.Types.ObjectId.isValid(bookid)) {
        return res.type('text').send('no book exists');
      }
      try {
        const deleted = await Book.findByIdAndDelete(bookid);
        if (!deleted) {
          return res.type('text').send('no book exists');
        }
        return res.type('text').send('delete successful');
      } catch (err) {
        return res.type('text').send('no book exists');
      }
    });

};