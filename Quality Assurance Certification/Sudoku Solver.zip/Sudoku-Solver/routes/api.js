'use strict';

const SudokuSolver = require('../controllers/sudoku-solver.js');

module.exports = function(app) {
  const solver = new SudokuSolver();

  // POST /api/solve
  app.route('/api/solve')
    .post((req, res) => {
      const { puzzle } = req.body;

      // Required field check
      if (puzzle === undefined) {
        return res.json({ error: 'Required field missing' });
      }

      // Validate puzzle string
      const valid = solver.validate(puzzle);
      if (valid !== true) {
        return res.json(valid);
      }

      // Attempt to solve
      const solution = solver.solve(puzzle);
      if (!solution) {
        return res.json({ error: 'Puzzle cannot be solved' });
      }

      // Success
      return res.json({ solution });
    });

  // POST /api/check
  app.route('/api/check')
    .post((req, res) => {
      const { puzzle, coordinate, value } = req.body;

      // Required fields
      if ([puzzle, coordinate, value].some(v => v === undefined)) {
        return res.json({ error: 'Required field(s) missing' });
      }

      // Validate puzzle
      const valid = solver.validate(puzzle);
      if (valid !== true) {
        return res.json(valid);
      }

      // Validate coordinate format A–I & 1–9
      if (!/^[A-I][1-9]$/.test(coordinate)) {
        return res.json({ error: 'Invalid coordinate' });
      }

      // Validate value (1–9)
      if (!/^[1-9]$/.test(value)) {
        return res.json({ error: 'Invalid value' });
      }

      // If the cell already contains that value, it's valid
      const row = coordinate[0];
      const col = coordinate[1];
      const idx = (row.charCodeAt(0) - 65) * 9 + (parseInt(col, 10) - 1);
      if (puzzle[idx] === value) {
        return res.json({ valid: true });
      }

      // Check conflicts
      const conflicts = [];
      if (!solver.checkRowPlacement(puzzle, row, col, value)) {
        conflicts.push('row');
      }
      if (!solver.checkColPlacement(puzzle, row, col, value)) {
        conflicts.push('column');
      }
      if (!solver.checkRegionPlacement(puzzle, row, col, value)) {
        conflicts.push('region');
      }

      // Return result
      return conflicts.length
        ? res.json({ valid: false, conflict: conflicts })
        : res.json({ valid: true });
    });
};
