const chai = require('chai');
const assert = chai.assert;

const Solver = require('../controllers/sudoku-solver.js');
const { puzzlesAndSolutions } = require('../controllers/puzzle-strings.js');

suite('Unit Tests', () => {
  let solver;

  suite('validate()', () => {
    test('Logic handles a valid puzzle string of 81 characters', () => {
      solver = new Solver();
      const input = puzzlesAndSolutions[0][0];
      const result = solver.validate(input);
      assert.isTrue(result);
    });

    test('Logic handles a puzzle string with invalid characters (not 1-9 or .)', () => {
      solver = new Solver();
      // inject an invalid character into a valid puzzle
      const invalidInput = puzzlesAndSolutions[0][0].slice(0, 80) + 'a';
      const result = solver.validate(invalidInput);
      assert.propertyVal(result, 'error', 'Invalid characters in puzzle');
    });

    test('Logic handles a puzzle string that is not 81 characters in length', () => {
      solver = new Solver();
      // trim one character to make length 80
      const shortInput = puzzlesAndSolutions[0][0].slice(0, 80);
      const result = solver.validate(shortInput);
      assert.propertyVal(result, 'error', 'Expected puzzle to be 81 characters long');
    });
  });

  suite('checkRowPlacement()', () => {
    const emptyGrid = '.'.repeat(81);

    test('Logic handles a valid row placement', () => {
      solver = new Solver();
      // empty row can accept any digit
      assert.isTrue(solver.checkRowPlacement(emptyGrid, 'A', '1', '5'));
    });

    test('Logic handles an invalid row placement', () => {
      solver = new Solver();
      // place '5' at A1, then try placing '5' again in same row at A2
      const rowConflict = '5' + '.'.repeat(80);
      assert.isFalse(solver.checkRowPlacement(rowConflict, 'A', '2', '5'));
    });
  });

  suite('checkColPlacement()', () => {
    const emptyGrid = '.'.repeat(81);

    test('Logic handles a valid column placement', () => {
      solver = new Solver();
      // empty column can accept any digit
      assert.isTrue(solver.checkColPlacement(emptyGrid, 'A', '1', '3'));
    });

    test('Logic handles an invalid column placement', () => {
      solver = new Solver();
      // place '7' at B1, then try placing '7' in same column at A1
      const colConflict = '.'.repeat(9) + '7' + '.'.repeat(71);
      assert.isFalse(solver.checkColPlacement(colConflict, 'A', '1', '7'));
    });
  });

  suite('checkRegionPlacement()', () => {
    const emptyGrid = '.'.repeat(81);

    test('Logic handles a valid region (3x3 grid) placement', () => {
      solver = new Solver();
      // top-left 3x3 region of empty grid can accept any digit
      assert.isTrue(solver.checkRegionPlacement(emptyGrid, 'A', '1', '9'));
    });

    test('Logic handles an invalid region (3x3 grid) placement', () => {
      solver = new Solver();
      // place '8' at A1, then try placing '8' again at A3 (same region)
      const regionConflict = '8' + '.'.repeat(80);
      assert.isFalse(solver.checkRegionPlacement(regionConflict, 'A', '3', '8'));
    });
  });

  suite('solve()', () => {
    test('Valid puzzle strings pass the solver', () => {
      solver = new Solver();
      puzzlesAndSolutions.forEach(([puzzle, solution]) => {
        assert.equal(solver.solve(puzzle), solution);
      });
    });

    test('Invalid puzzle strings fail the solver', () => {
      solver = new Solver();
      // turn all dots into invalid 'a' characters
      puzzlesAndSolutions.forEach(([puzzle]) => {
        const invalidPuzzle = puzzle.replace(/\./g, 'a');
        assert.isFalse(solver.solve(invalidPuzzle));
      });
    });

    test('Solver returns the expected solution for an incomplete puzzle', () => {
      solver = new Solver();
      const [puzzle, solution] = puzzlesAndSolutions[0];
      assert.equal(solver.solve(puzzle), solution);
    });
  });
});
