const chai = require("chai");
const chaiHttp = require("chai-http");
const assert = chai.assert;
const server = require("../server");
const { puzzlesAndSolutions } = require("../controllers/puzzle-strings.js");

chai.use(chaiHttp);

suite("Functional Tests", () => {
  const validPuzzle = puzzlesAndSolutions[0][0];
  const validSolution = puzzlesAndSolutions[0][1];

  // A puzzle with a single '1' in A1, rest empty
  const conflictPuzzle = "1" + ".".repeat(80);

  // A puzzle with '1' at A1, A2, and B1 to force row, column and region conflicts at B2
  const puzzleAllConflicts = (() => {
    const arr = Array(81).fill(".");
    arr[0] = "1";  // A1
    arr[1] = "1";  // A2
    arr[9] = "1";  // B1
    return arr.join("");
  })();

  suite("POST /api/solve", () => {
    test("Solve a puzzle with valid puzzle string", done => {
      chai.request(server)
        .post("/api/solve")
        .send({ puzzle: validPuzzle })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.property(res.body, "solution");
          assert.equal(res.body.solution, validSolution);
          done();
        });
    });

    test("Solve a puzzle with missing puzzle string", done => {
      chai.request(server)
        .post("/api/solve")
        .send({})
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(res.body, "error", "Required field missing");
          done();
        });
    });

    test("Solve a puzzle with invalid characters", done => {
      const invalid = validPuzzle.replace(/\./g, "x");
      chai.request(server)
        .post("/api/solve")
        .send({ puzzle: invalid })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(res.body, "error", "Invalid characters in puzzle");
          done();
        });
    });

    test("Solve a puzzle with incorrect length", done => {
      const shortPuzzle = validPuzzle.slice(1); // 80 chars
      chai.request(server)
        .post("/api/solve")
        .send({ puzzle: shortPuzzle })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(
            res.body,
            "error",
            "Expected puzzle to be 81 characters long"
          );
          done();
        });
    });

    test("Solve a puzzle that cannot be solved", done => {
      const unsolvable = "1".repeat(81);
      chai.request(server)
        .post("/api/solve")
        .send({ puzzle: unsolvable })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(res.body, "error", "Puzzle cannot be solved");
          done();
        });
    });
  });

  suite("POST /api/check", () => {
    test("Check a puzzle placement with all fields", done => {
      chai.request(server)
        .post("/api/check")
        .send({ puzzle: validPuzzle, coordinate: "A2", value: "3" })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(res.body, "valid", true);
          done();
        });
    });

    test("Check a puzzle placement with single placement conflict", done => {
      chai.request(server)
        .post("/api/check")
        .send({ puzzle: conflictPuzzle, coordinate: "A5", value: "1" })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(res.body, "valid", false);
          assert.deepEqual(res.body.conflict, ["row"]);
          done();
        });
    });

    test("Check a puzzle placement with multiple placement conflicts", done => {
      chai.request(server)
        .post("/api/check")
        .send({ puzzle: conflictPuzzle, coordinate: "B1", value: "1" })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(res.body, "valid", false);
          assert.deepEqual(res.body.conflict.sort(), ["column", "region"]);
          done();
        });
    });

    test("Check a puzzle placement with all placement conflicts", done => {
      chai.request(server)
        .post("/api/check")
        .send({ puzzle: puzzleAllConflicts, coordinate: "B2", value: "1" })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(res.body, "valid", false);
          assert.deepEqual(
            res.body.conflict.sort(),
            ["column", "region", "row"]
          );
          done();
        });
    });

    test("Check a puzzle placement with missing required fields", done => {
      chai.request(server)
        .post("/api/check")
        .send({ puzzle: validPuzzle, coordinate: "A2" })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(
            res.body,
            "error",
            "Required field(s) missing"
          );
          done();
        });
    });

    test("Check a puzzle placement with invalid characters", done => {
      const invalid = validPuzzle.replace(/\./g, "x");
      chai.request(server)
        .post("/api/check")
        .send({ puzzle: invalid, coordinate: "A2", value: "3" })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(
            res.body,
            "error",
            "Invalid characters in puzzle"
          );
          done();
        });
    });

    test("Check a puzzle placement with incorrect length", done => {
      const shortPuzzle = validPuzzle.slice(1);
      chai.request(server)
        .post("/api/check")
        .send({ puzzle: shortPuzzle, coordinate: "A2", value: "3" })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(
            res.body,
            "error",
            "Expected puzzle to be 81 characters long"
          );
          done();
        });
    });

    test("Check a puzzle placement with invalid placement coordinate", done => {
      chai.request(server)
        .post("/api/check")
        .send({ puzzle: validPuzzle, coordinate: "Z10", value: "3" })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(res.body, "error", "Invalid coordinate");
          done();
        });
    });

    test("Check a puzzle placement with invalid placement value", done => {
      chai.request(server)
        .post("/api/check")
        .send({ puzzle: validPuzzle, coordinate: "A2", value: "0" })
        .end((err, res) => {
          assert.equal(res.status, 200);
          assert.propertyVal(res.body, "error", "Invalid value");
          done();
        });
    });
  });
});