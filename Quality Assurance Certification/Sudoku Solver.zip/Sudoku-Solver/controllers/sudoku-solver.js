class SudokuSolver {

  // 1. Validate puzzle string
  validate(puzzleString) {
    if (puzzleString == null) {
      return { error: 'Required field missing' };
    }
    if (puzzleString.length !== 81) {
      return { error: 'Expected puzzle to be 81 characters long' };
    }
    if (/[^1-9.]/.test(puzzleString)) {
      return { error: 'Invalid characters in puzzle' };
    }
    return true;
  }

  // 2. Check row placement
  checkRowPlacement(puzzleString, row, column, value) {
    const r = row.charCodeAt(0) - 'A'.charCodeAt(0);
    const c = parseInt(column, 10) - 1;
    const base = r * 9;
    for (let i = 0; i < 9; i++) {
      if (i === c) continue;
      if (puzzleString[base + i] === value) return false;
    }
    return true;
  }

  // 3. Check column placement
  checkColPlacement(puzzleString, row, column, value) {
    const r = row.charCodeAt(0) - 'A'.charCodeAt(0);
    const c = parseInt(column, 10) - 1;
    for (let i = 0; i < 9; i++) {
      if (i === r) continue;
      if (puzzleString[i * 9 + c] === value) return false;
    }
    return true;
  }

  // 4. Check 3x3 region placement
  checkRegionPlacement(puzzleString, row, column, value) {
    const r = row.charCodeAt(0) - 'A'.charCodeAt(0);
    const c = parseInt(column, 10) - 1;
    const boxRow = Math.floor(r / 3) * 3;
    const boxCol = Math.floor(c / 3) * 3;
    for (let dr = 0; dr < 3; dr++) {
      for (let dc = 0; dc < 3; dc++) {
        const rr = boxRow + dr;
        const cc = boxCol + dc;
        if (rr === r && cc === c) continue;
        if (puzzleString[rr * 9 + cc] === value) return false;
      }
    }
    return true;
  }

  // 5. Solve via backtracking
  solve(puzzleString) {
    // a) Validate initial string
    if (this.validate(puzzleString) !== true) return false;

    // b) If fully filled, double-check validity
    if (!puzzleString.includes('.')) {
      for (let idx = 0; idx < 81; idx++) {
        const val = puzzleString[idx];
        const row = String.fromCharCode(65 + Math.floor(idx / 9));
        const col = String((idx % 9) + 1);
        if (
          !this.checkRowPlacement(puzzleString, row, col, val) ||
          !this.checkColPlacement(puzzleString, row, col, val) ||
          !this.checkRegionPlacement(puzzleString, row, col, val)
        ) {
          return false;
        }
      }
      // Fully filled and valid
      return puzzleString;
    }

    // c) Otherwise backtrack
    const grid = puzzleString.split('');
    const backtrack = () => {
      const emptyIdx = grid.indexOf('.');
      if (emptyIdx < 0) return true; // solved

      const row = String.fromCharCode(65 + Math.floor(emptyIdx / 9));
      const col = String((emptyIdx % 9) + 1);

      for (let num = 1; num <= 9; num++) {
        const val = num.toString();
        const attempt = grid.join('');
        if (
          this.checkRowPlacement(attempt, row, col, val) &&
          this.checkColPlacement(attempt, row, col, val) &&
          this.checkRegionPlacement(attempt, row, col, val)
        ) {
          grid[emptyIdx] = val;
          if (backtrack()) return true;
          grid[emptyIdx] = '.';
        }
      }
      return false;
    };

    return backtrack() ? grid.join('') : false;
  }
}

module.exports = SudokuSolver;