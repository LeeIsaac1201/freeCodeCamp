'use strict';

const mongoose = require('mongoose');
const { Schema } = mongoose;

module.exports = function (app) {
  // 1) Define the Issue schema & model
  const issueSchema = new Schema({
    project:     { type: String, required: true },
    issue_title: { type: String, required: true },
    issue_text:  { type: String, required: true },
    created_by:  { type: String, required: true },
    assigned_to: { type: String, default: '' },
    status_text: { type: String, default: '' },
    created_on:  { type: Date, default: Date.now },
    updated_on:  { type: Date, default: Date.now },
    open:        { type: Boolean, default: true }
  });

  const Issue = mongoose.model('Issue', issueSchema);

  // 2) Mount the CRUD routes
  app.route('/api/issues/:project')

    // GET  /api/issues/{project} → list & filter
    .get(async (req, res) => {
      const project = req.params.project;
      const filter = { project };

      // apply any query filters
      Object.entries(req.query).forEach(([key, val]) => {
        if (key === 'open') {
          filter.open = val === 'false' ? false : true;
        } else {
          filter[key] = val;
        }
      });

      try {
        const issues = await Issue.find(filter)
          .select('-__v -project')
          .lean();
        return res.json(issues);
      } catch (err) {
        // on error, return empty array
        return res.json([]);
      }
    })

    // POST /api/issues/{project} → create new issue
    .post(async (req, res) => {
      const project = req.params.project;
      const {
        issue_title,
        issue_text,
        created_by,
        assigned_to = '',
        status_text = ''
      } = req.body;

      // required fields
      if (!issue_title || !issue_text || !created_by) {
        return res.json({ error: 'required field(s) missing' });
      }

      try {
        const newIssue = await Issue.create({
          project,
          issue_title,
          issue_text,
          created_by,
          assigned_to,
          status_text
        });
        // convert to plain object, remove mongoose internals
        const obj = newIssue.toObject();
        delete obj.__v;
        delete obj.project;
        return res.json(obj);
      } catch (err) {
        return res.json({ error: 'could not create issue' });
      }
    })

    // PUT  /api/issues/{project} → update an issue
    .put(async (req, res) => {
      const project = req.params.project;
      const { _id, ...fields } = req.body;

      if (!_id) {
        return res.json({ error: 'missing _id' });
      }

      // build update payload, ignore empty strings
      const updates = {};
      Object.entries(fields).forEach(([k, v]) => {
        if (v !== undefined && v !== '') {
          updates[k] = v;
        }
      });

      if (Object.keys(updates).length === 0) {
        return res.json({ error: 'no update field(s) sent', _id });
      }

      updates.updated_on = new Date();

      try {
        const updated = await Issue.findOneAndUpdate(
          { _id, project },
          updates,
          { new: true }
        );
        if (!updated) throw new Error('not found');
        return res.json({ result: 'successfully updated', _id });
      } catch (err) {
        return res.json({ error: 'could not update', _id });
      }
    })

    // DELETE /api/issues/{project} → delete an issue
    .delete(async (req, res) => {
      const project = req.params.project;
      const { _id } = req.body;

      if (!_id) {
        return res.json({ error: 'missing _id' });
      }

      try {
        const deleted = await Issue.findOneAndDelete({ _id, project });
        if (!deleted) throw new Error('not found');
        return res.json({ result: 'successfully deleted', _id });
      } catch (err) {
        return res.json({ error: 'could not delete', _id });
      }
    });
}