'use strict';

// 1) ENV + MongoDB Connection
require('dotenv').config();
const mongoose = require('mongoose');

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser:    true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ MongoDB Connected'))
.catch(err => {
  console.error('❌ MongoDB connection error:', err);
  process.exit(1);
});

// 2) App Setup
const express    = require('express');
const bodyParser = require('body-parser');
const cors       = require('cors');
const expect     = require('chai').expect;

const apiRoutes        = require('./routes/api.js');
const fccTestingRoutes = require('./routes/fcctesting.js');
const runner           = require('./test-runner');

const app = express();

// 3) Middleware
app.use('/public', express.static(process.cwd() + '/public'));
app.use(cors({ origin: '*' }));       // FCC testing
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 4) Front-end Routes
app.route('/:project/')
  .get((req, res) => {
    res.sendFile(process.cwd() + '/views/issue.html');
  });

app.route('/')
  .get((req, res) => {
    res.sendFile(process.cwd() + '/views/index.html');
  });

// 5) FCC Testing & API
fccTestingRoutes(app);
apiRoutes(app);

// 6) 404 Middleware
app.use((req, res, next) => {
  res.status(404)
     .type('text')
     .send('Not Found');
});

// 7) Start Server + Run Tests
const listener = app.listen(process.env.PORT || 3000, () => {
  console.log('Your app is listening on port ' + listener.address().port);
  if (process.env.NODE_ENV === 'test') {
    console.log('Running Tests...');
    // wait for the DB + server fully up
    setTimeout(() => {
      try {
        runner.run();
      } catch (err) {
        console.error('Tests are not valid:', err);
      }
    }, 3500);
  }
});

module.exports = app;  // for testing
