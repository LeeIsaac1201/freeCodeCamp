const chaiHttp = require('chai-http');
const chai     = require('chai');
const assert   = chai.assert;
const server   = require('../server');

chai.use(chaiHttp);

suite('Functional Tests', function() {
  let issueIdAllFields;
  let issueIdReqFields;
  const project = 'testproj';

  suite('POST /api/issues/{project}', function() {

    test('Create an issue with every field', function(done) {
      chai.request(server)
        .post(`/api/issues/${project}`)
        .send({
          issue_title: 'All Fields',
          issue_text:  'Testing complete fields',
          created_by:  'Tester',
          assigned_to: 'Dev Team',
          status_text: 'In QA'
        })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.property(res.body, '_id');
          issueIdAllFields = res.body._id;
          assert.equal(res.body.issue_title, 'All Fields');
          assert.equal(res.body.issue_text, 'Testing complete fields');
          assert.equal(res.body.created_by, 'Tester');
          assert.equal(res.body.assigned_to, 'Dev Team');
          assert.equal(res.body.status_text, 'In QA');
          assert.isTrue(res.body.open);
          assert.property(res.body, 'created_on');
          assert.property(res.body, 'updated_on');
          done();
        });
    });

    test('Create an issue with only required fields', function(done) {
      chai.request(server)
        .post(`/api/issues/${project}`)
        .send({
          issue_title: 'Req Only',
          issue_text:  'Only required fields',
          created_by:  'Tester'
        })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.property(res.body, '_id');
          issueIdReqFields = res.body._id;
          assert.equal(res.body.issue_title, 'Req Only');
          assert.equal(res.body.issue_text, 'Only required fields');
          assert.equal(res.body.created_by, 'Tester');
          assert.equal(res.body.assigned_to, '');
          assert.equal(res.body.status_text, '');
          assert.isTrue(res.body.open);
          assert.property(res.body, 'created_on');
          assert.property(res.body, 'updated_on');
          done();
        });
    });

    test('Create an issue with missing required fields', function(done) {
      chai.request(server)
        .post(`/api/issues/${project}`)
        .send({
          issue_title: 'Missing Text'
          // missing issue_text and created_by
        })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.deepEqual(res.body, { error: 'required field(s) missing' });
          done();
        });
    });
  });

  suite('GET /api/issues/{project}', function() {

    test('View issues on a project', function(done) {
      chai.request(server)
        .get(`/api/issues/${project}`)
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.isArray(res.body);
          assert.isAtLeast(res.body.length, 2);
          res.body.forEach(issue => {
            assert.property(issue, 'issue_title');
            assert.property(issue, 'issue_text');
            assert.property(issue, 'created_by');
            assert.property(issue, 'assigned_to');
            assert.property(issue, 'status_text');
            assert.property(issue, 'open');
            assert.property(issue, '_id');
          });
          done();
        });
    });

    test('View issues on a project with one filter', function(done) {
      chai.request(server)
        .get(`/api/issues/${project}`)
        .query({ open: 'true' })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.isArray(res.body);
          res.body.forEach(issue => {
            assert.isTrue(issue.open);
          });
          done();
        });
    });

    test('View issues on a project with multiple filters', function(done) {
      chai.request(server)
        .get(`/api/issues/${project}`)
        .query({ open: 'true', assigned_to: 'Dev Team' })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.isArray(res.body);
          res.body.forEach(issue => {
            assert.isTrue(issue.open);
            assert.equal(issue.assigned_to, 'Dev Team');
          });
          done();
        });
    });

  });

  suite('PUT /api/issues/{project}', function() {

    test('Update one field on an issue', function(done) {
      chai.request(server)
        .put(`/api/issues/${project}`)
        .send({
          _id: issueIdAllFields,
          issue_text: 'Updated text only'
        })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.deepEqual(res.body, {
            result: 'successfully updated',
            _id: issueIdAllFields
          });
          done();
        });
    });

    test('Update multiple fields on an issue', function(done) {
      chai.request(server)
        .put(`/api/issues/${project}`)
        .send({
          _id: issueIdAllFields,
          assigned_to: 'QA Team',
          status_text: 'Resolved'
        })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.deepEqual(res.body, {
            result: 'successfully updated',
            _id: issueIdAllFields
          });
          done();
        });
    });

    test('Update an issue with missing _id', function(done) {
      chai.request(server)
        .put(`/api/issues/${project}`)
        .send({
          issue_text: 'No ID provided'
        })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.deepEqual(res.body, { error: 'missing _id' });
          done();
        });
    });

    test('Update an issue with no fields to update', function(done) {
      chai.request(server)
        .put(`/api/issues/${project}`)
        .send({ _id: issueIdAllFields })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.deepEqual(res.body, {
            error: 'no update field(s) sent',
            _id: issueIdAllFields
          });
          done();
        });
    });

    test('Update an issue with an invalid _id', function(done) {
      const invalidId = '000000000000000000000000';
      chai.request(server)
        .put(`/api/issues/${project}`)
        .send({
          _id: invalidId,
          issue_text: 'Won’t work'
        })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.deepEqual(res.body, {
            error: 'could not update',
            _id: invalidId
          });
          done();
        });
    });

  });

  suite('DELETE /api/issues/{project}', function() {

    test('Delete an issue', function(done) {
      chai.request(server)
        .delete(`/api/issues/${project}`)
        .send({ _id: issueIdReqFields })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.deepEqual(res.body, {
            result: 'successfully deleted',
            _id: issueIdReqFields
          });
          done();
        });
    });

    test('Delete an issue with an invalid _id', function(done) {
      const invalidId = '000000000000000000000000';
      chai.request(server)
        .delete(`/api/issues/${project}`)
        .send({ _id: invalidId })
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.deepEqual(res.body, {
            error: 'could not delete',
            _id: invalidId
          });
          done();
        });
    });

    test('Delete an issue with missing _id', function(done) {
      chai.request(server)
        .delete(`/api/issues/${project}`)
        .send({})
        .end(function(err, res) {
          assert.equal(res.status, 200);
          assert.deepEqual(res.body, { error: 'missing _id' });
          done();
        });
    });

  });

})