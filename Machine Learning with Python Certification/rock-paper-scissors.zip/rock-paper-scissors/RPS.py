# Counter is used to count move frequencies (helps to identify the most common moves)
from collections import Counter

# Persistent histories across calls
OPP_HISTORY = []
MY_HISTORY = []

# Maps for counters: Ideal response and double response
IDEAL_RESPONSE = {'P': 'S', 'R': 'P', 'S': 'R'}
DOUBLE_RESPONSE = {
    'R': IDEAL_RESPONSE[IDEAL_RESPONSE['R']],
    'P': IDEAL_RESPONSE[IDEAL_RESPONSE['P']],
    'S': IDEAL_RESPONSE[IDEAL_RESPONSE['S']],
}


# Return the most common element in sequence, breaking ties by most recent occurrence
def _most_common(seq):
    if not seq:
        return None
    c = Counter(seq)
    top_count = max(c.values())
    candidates = [m for m, cnt in c.items() if cnt == top_count]
    for x in reversed(seq):
        if x in candidates:
            return x
    return candidates[0]


# Predict the opponent's next move by finding previous occurrences of the recent suffix
def _sequence_predict(opponent_history, max_lookback=10):
    n = len(opponent_history)
    for L in range(min(max_lookback, n), 0, -1):
        pattern = tuple(opponent_history[-L:])
        next_moves = []
        for i in range(n - L):
            if tuple(opponent_history[i:i + L]) == pattern:
                if i + L < n:
                    next_moves.append(opponent_history[i + L])
        if next_moves:
            return _most_common(next_moves)
    return None


# Main player function: update histories and use multiple heuristics to pick a move
def player(prev_play, opponent_history=[]):
    # Update persistent and provided opponent histories
    if prev_play:
        OPP_HISTORY.append(prev_play)
    if prev_play:
        opponent_history.append(prev_play)

    opp = OPP_HISTORY
    me = MY_HISTORY

    # Detect reactive opponent (e.g., kris) and exploit by playing double-counter
    if len(opp) >= 6 and len(me) >= 5:
        matches = 0
        total = 0
        for i in range(1, len(opp)):
            if i - 1 < len(me):
                total += 1
                if opp[i] == IDEAL_RESPONSE.get(me[i - 1], ''):
                    matches += 1
        if total > 0:
            ratio = matches / total
            if ratio > 0.65:
                if me:
                    play = DOUBLE_RESPONSE.get(me[-1], 'R')
                else:
                    play = 'R'
                me.append(play)
                return play

    # Detect frequency-based opponent (e.g., mrugesh) and exploit by countering the expected play
    if len(me) >= 5 and len(opp) >= 5:
        my_recent = me[-10:]
        my_most = _most_common(my_recent)
        if my_most:
            look = min(len(opp), 10)
            opp_recent = opp[-look:]
            expected = IDEAL_RESPONSE.get(my_most)
            if expected:
                match_count = sum(1 for x in opp_recent if x == expected)
                if look > 0 and (match_count / look) > 0.6:
                    play = DOUBLE_RESPONSE.get(my_most, 'R')
                    me.append(play)
                    return play

    # Use sequence prediction to anticipate Markov-like opponents (e.g., abbey, quincy)
    predicted = _sequence_predict(opp, max_lookback=10)
    if predicted:
        play = IDEAL_RESPONSE.get(predicted, 'R')
        me.append(play)
        return play

    # Short-term frequency fallback: play the counter to opponent's recent most common move
    if opp:
        pred = _most_common(opp[-10:])
        if pred:
            play = IDEAL_RESPONSE.get(pred, 'R')
            me.append(play)
            return play

    # Default behavior / simple rotation when no strong signal exists
    if me:
        last = me[-1]
        play = DOUBLE_RESPONSE.get(last, 'R')
    else:
        play = 'R'

    me.append(play)
    return play
