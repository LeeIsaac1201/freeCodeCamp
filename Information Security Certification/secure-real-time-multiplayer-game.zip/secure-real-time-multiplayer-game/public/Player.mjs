// Define the Player class, initialising properties for position, score, and identification.
class Player {
  constructor({ x, y, score, id }) {
    this.x = x;
    this.y = y;
    this.score = score;
    this.id = id;
  }
  // Define the movePlayer method to adjust position based on direction and enforce boundary checks.
  movePlayer(dir, speed) {
    // Update position based on direction.
    switch (dir) {
      case 'up':
        this.y -= speed;
        break;
      case 'down':
        this.y += speed;
        break;
      case 'left':
        this.x -= speed;
        break;
      case 'right':
        this.x += speed;
        break;
    }

    // Keep player within canvas bounds (640x480).
    if (this.x < 0) this.x = 0;
    if (this.x > 640) this.x = 640;
    if (this.y < 0) this.y = 0;
    if (this.y > 480) this.y = 480;
  }
  // Define the collision method to check for a bounding box overlap with a collectible item.
  collision(item) {
    // Check if player intersects with collectible item
    // Assuming both player and item have a size (default ~30 pixels)
    const playerSize = 30;
    const itemSize = 30;

    // Check if rectangles overlap
    if (this.x < item.x + itemSize &&
      this.x + playerSize > item.x &&
      this.y < item.y + itemSize &&
      this.y + playerSize > item.y) {
      return true;
    }
    return false;
  }
  // Define the calculateRank method to determine and format the player's current rank among all players.
  calculateRank(arr) {
    // Count how many players have a higher score than this player
    let rank = 1;
    for (let player of arr) {
      if (player.score > this.score) {
        rank++;
      }
    }
    return `Rank: ${rank}/${arr.length}`; // Return rank in format "Rank: currentRank/totalPlayers"
  }
}

export default Player; // Export the Player class as the default module export.