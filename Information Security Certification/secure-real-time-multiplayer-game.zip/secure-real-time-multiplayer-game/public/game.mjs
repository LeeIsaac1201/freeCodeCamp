// Import the Player and Collectible classes
import Player from './Player.mjs';
import Collectible from './Collectible.mjs';
// Initialise the socket connection, get the canvas element, and its 2D context
const socket = io();
const canvas = document.getElementById('game-window');
const context = canvas.getContext('2d');
// Define the main game state variables
let currentPlayer = null;
let players = {};
let collectible = null;

// Handle keyboard input
const keys = {};
document.addEventListener('keydown', (e) => {
  keys[e.key] = true;
});
// Set up event listeners to track the state of keyboard keys.
document.addEventListener('keyup', (e) => {
  keys[e.key] = false;
});

// Initialise game when receiving data from server
socket.on('init', (data) => {
  // Create current player
  currentPlayer = new Player({
    x: data.players[data.id].x,
    y: data.players[data.id].y,
    score: data.players[data.id].score,
    id: data.id
  });

  // Create other players
  for (let id in data.players) {
    if (id !== data.id) {
      players[id] = new Player(data.players[id]);
    }
  }

  // Create collectible: Handle the initial 'init' data from the server, setting up the current player, other players, and the collectible.
  collectible = new Collectible(data.collectible);
});

// Handle new player joining: Handle the 'new-player' event to add a new player to the local state.
socket.on('new-player', (playerData) => {
  players[playerData.id] = new Player(playerData);
});

// Handle player position updates: Update the position of an existing player based on server data.
socket.on('update-player', (data) => {
  if (data.id !== currentPlayer?.id && players[data.id]) {
    players[data.id].x = data.x;
    players[data.id].y = data.y;
  }
});

// Handle collectible updates: Update the collectible's position or state based on server data.
socket.on('update-collectible', (data) => {
  collectible = new Collectible(data);
});

// Handle score updates: Update the score for the current player or an opposing player.
socket.on('update-score', (data) => {
  if (data.id === currentPlayer?.id) {
    currentPlayer.score = data.score;
  } else if (players[data.id]) {
    players[data.id].score = data.score;
  }
});

// Handle player disconnect: Remove a disconnected player from the local state.
socket.on('remove-player', (id) => {
  delete players[id];
});

// Game loop
function gameLoop() {
  if (!currentPlayer) return;

  // Handle player movement
  const speed = 5;
  let moved = false;

  if (keys['w'] || keys['W'] || keys['ArrowUp']) {
    currentPlayer.movePlayer('up', speed);
    moved = true;
  }
  if (keys['s'] || keys['S'] || keys['ArrowDown']) {
    currentPlayer.movePlayer('down', speed);
    moved = true;
  }
  if (keys['a'] || keys['A'] || keys['ArrowLeft']) {
    currentPlayer.movePlayer('left', speed);
    moved = true;
  }
  if (keys['d'] || keys['D'] || keys['ArrowRight']) {
    currentPlayer.movePlayer('right', speed);
    moved = true;
  }

  // Send position update to server if moved
  if (moved) {
    socket.emit('move-player', {
      x: currentPlayer.x,
      y: currentPlayer.y
    });
  }

  // Check collision with collectible
  if (collectible && currentPlayer.collision(collectible)) {
    socket.emit('collect-item');
  }

  // Render game: Define the main game loop, handling input, player movement, collision detection, and server communication.
  render();
}

function render() {
  // Clear canvas
  context.fillStyle = '#220';
  context.fillRect(0, 0, canvas.width, canvas.height);

  // Draw collectible
  if (collectible) {
    context.fillStyle = 'gold';
    context.fillRect(collectible.x, collectible.y, 30, 30);
    context.fillStyle = 'white';
    context.font = '12px Arial';
    context.fillText(collectible.value, collectible.x + 10, collectible.y + 20);
  }

  // Draw other players
  for (let id in players) {
    const player = players[id];
    context.fillStyle = 'blue';
    context.fillRect(player.x, player.y, 30, 30);
    context.fillStyle = 'white';
    context.font = '10px Arial';
    context.fillText(`${player.score}`, player.x + 8, player.y + 20);
  }

  // Draw current player
  if (currentPlayer) {
    context.fillStyle = 'green';
    context.fillRect(currentPlayer.x, currentPlayer.y, 30, 30);
    context.fillStyle = 'white';
    context.font = '10px Arial';
    context.fillText(`${currentPlayer.score}`, currentPlayer.x + 8, currentPlayer.y + 20);

    // Display rank
    const allPlayers = [currentPlayer, ...Object.values(players)];
    const rank = currentPlayer.calculateRank(allPlayers);
    context.fillStyle = 'white';
    context.font = '16px "Press Start 2P"';
    context.fillText(rank, 10, 30);
    context.fillText(`Score: ${currentPlayer.score}`, 10, 60);
  }

  // Display controls: Define the render function to clear the canvas and draw all game elements (players, collectible, scores, and the user interface).
  context.fillStyle = 'white';
  context.font = '12px Arial';
  context.fillText('Use WASD or Arrow keys to move', 10, canvas.height - 10);
}

// Start game loop: Set the game loop to run at approximately 60 frames per second.
setInterval(gameLoop, 1000 / 60);