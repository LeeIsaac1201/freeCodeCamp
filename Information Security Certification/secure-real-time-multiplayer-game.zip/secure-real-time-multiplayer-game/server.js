// Import necessary modules and load environment variables
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const expect = require('chai');
const socket = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
// Import FreeCodeCamp testing routes and test runner
const fccTestingRoutes = require('./routes/fcctesting.js');
const runner = require('./test-runner.js');

const app = express();

// Helmet security configuration (v3.21.3) to prevent MIME type sniffing, XSS attacks, caching, and to hide X-Powered-By header
app.use(helmet.noSniff()); 
app.use(helmet.xssFilter()); 
app.use(helmet.noCache()); 
app.use(helmet.hidePoweredBy({ setTo: 'PHP 7.4.3' }));
// Serve static files from the 'public' and 'assets' directories.
app.use('/public', express.static(process.cwd() + '/public'));
app.use('/assets', express.static(process.cwd() + '/assets'));
// Configure Express to parse JavaScript Object Notation (JSON) and uniform resource locator (URL)-encoded body data.
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//For freeCodeCamp testing purposes and enables user to connect from outside the hosting platform
app.use(cors({origin: '*'})); 

// Index page (static Hypertext Markup Language (HTML))
app.route('/')
  .get(function (req, res) {
    res.sendFile(process.cwd() + '/views/index.html');
  }); 

//For freeCodeCamp testing purposes
fccTestingRoutes(app);

// Define the 404 handler for unmatched routes
app.use(function(req, res, next) {
  res.status(404)
    .type('text')
    .send('Not Found');
});

const portNum = process.env.PORT || 3000;

// Set up server and tests: Start the Express server and conditionally run tests if in 'test' environment.
const server = app.listen(portNum, () => {
  console.log(`Listening on port ${portNum}`);
  if (process.env.NODE_ENV==='test') {
    console.log('Running Tests...');
    setTimeout(function () {
      try {
        runner.run();
      } catch (error) {
        console.log('Tests are not valid:');
        console.error(error);
      }
    }, 1500);
  }
});

// Socket.io setup: Attach Socket.IO to the Express server.
const io = socket(server);

// Store connected players: Initialise game state variables (players and the collectible item).
const players = {};
let collectible = null;

// Generate random position within bounds: Function to generate safe, random coordinates within the game map bounds.
function generatePosition() {
  return {
    x: Math.floor(Math.random() * 600) + 20,
    y: Math.floor(Math.random() * 440) + 20
  };
}

// Generate new collectible: Function to create a new collectible object with a random position and value.
function generateCollectible() {
  const pos = generatePosition();
  return {
    x: pos.x,
    y: pos.y,
    value: Math.floor(Math.random() * 5) + 1,
    id: Date.now() + Math.random()
  };
}

// Initialise first collectible: Create the first collectible item when the server starts.
collectible = generateCollectible();

io.on('connection', (socket) => {
  console.log('New player connected:', socket.id);

  // Create new player
  const pos = generatePosition();
  players[socket.id] = {
    x: pos.x,
    y: pos.y,
    score: 0,
    id: socket.id
  };

  // Send initial game state to new player
  socket.emit('init', {
    id: socket.id,
    players: players,
    collectible: collectible
  });

  // Broadcast new player to all other players
  socket.broadcast.emit('new-player', players[socket.id]);

  // Handle player movement
  socket.on('move-player', (movementData) => {
    if (players[socket.id]) {
      players[socket.id].x = movementData.x;
      players[socket.id].y = movementData.y;

      // Broadcast updated position to all players
      io.emit('update-player', {
        id: socket.id,
        x: movementData.x,
        y: movementData.y
      });
    }
  });

  // Handle collectible collection
  socket.on('collect-item', () => {
    if (players[socket.id] && collectible) {
      players[socket.id].score += collectible.value;

      // Generate new collectible
      collectible = generateCollectible();

      // Broadcast new collectible and updated score to all players
      io.emit('update-collectible', collectible);
      io.emit('update-score', {
        id: socket.id,
        score: players[socket.id].score
      });
    }
  });

  // Handle player disconnect
  socket.on('disconnect', () => {
    console.log('Player disconnected:', socket.id);
    delete players[socket.id];
    io.emit('remove-player', socket.id);
  });
});

module.exports = app; // For testing