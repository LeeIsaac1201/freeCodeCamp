import hashlib # Import the hashlib module for SHA-1 hashing operations

def crack_sha1_hash(hash_to_crack, use_salts=False):
    # Load password list from file into a list of non empty stripped lines
    try:
        with open("top-10000-passwords.txt", "r", encoding="utf-8", errors="ignore") as f:
            passwords = [line.strip() for line in f if line.strip() != ""]
    except FileNotFoundError:
        # Return failure string when password file is not available
        return "PASSWORD NOT IN DATABASE"

    # Load known salts when salting is requested
    salts = []
    if use_salts:
        try:
            with open("known-salts.txt", "r", encoding="utf-8", errors="ignore") as sf:
                salts = [line.strip() for line in sf if line.strip() != ""]
        except FileNotFoundError:
            # Proceed without salts if salt file is missing
            salts = []

    # Normalize the target hash to lowercase for reliable comparison
    target = hash_to_crack.lower()

    # Try each password from the list without salts
    for pwd in passwords:
        h = hashlib.sha1(pwd.encode("utf-8")).hexdigest()
        if h == target:
            # Return the matching plain password
            return pwd

    # If requested try salted variants using the known salts
    if use_salts and salts:
        for pwd in passwords:
            for s in salts:
                # Try salt prepended and appended around the password
                candidate1 = f"{s}{pwd}{s}"
                if hashlib.sha1(candidate1.encode("utf-8")).hexdigest() == target:
                    return pwd
                # Try salt prepended to the password
                candidate2 = f"{s}{pwd}"
                if hashlib.sha1(candidate2.encode("utf-8")).hexdigest() == target:
                    return pwd
                # Try salt appended to the password
                candidate3 = f"{pwd}{s}"
                if hashlib.sha1(candidate3.encode("utf-8")).hexdigest() == target:
                    return pwd

    # Return the specified string when no match is found
    return "PASSWORD NOT IN DATABASE"