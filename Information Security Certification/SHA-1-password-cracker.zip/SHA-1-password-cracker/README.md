# SHA-1 Password Cracker

This is the boilerplate for the SHA-1 Password Cracker project. Instructions for building your project can be found at https://www.freecodecamp.org/learn/information-security/information-security-projects/sha-1-password-cracker
