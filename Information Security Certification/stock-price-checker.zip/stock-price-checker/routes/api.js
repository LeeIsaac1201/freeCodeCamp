'use strict';
const crypto = require('crypto');

// In-memory storage for likes (use MongoDB in production)
const stockLikes = new Map();

// Anonymise Internet Protocol (IP) address using SHA256 hash
function anonymizeIP(ip) {
  return crypto.createHash('sha256').update(ip).digest('hex');
}

// Fetch stock data from the proxy Application Programming Interface (API)
async function getStockPrice(symbol) {
  try {
    const response = await fetch(
      `https://stock-price-checker-proxy.freecodecamp.rocks/v1/stock/${symbol}/quote`
    );
    const data = await response.json();
    return data;
  } catch (error) {
    return null;
  }
}

// Get likes for a stock
function getLikes(stock) {
  return stockLikes.has(stock) ? stockLikes.get(stock).size : 0;
}

// Add a like for a stock from an IP address
function addLike(stock, ipHash) {
  if (!stockLikes.has(stock)) {
    stockLikes.set(stock, new Set());
  }
  stockLikes.get(stock).add(ipHash);
}

// Check if IP has already liked a stock
function hasLiked(stock, ipHash) {
  return stockLikes.has(stock) && stockLikes.get(stock).has(ipHash);
}

module.exports = function (app) {
  app.route('/api/stock-prices')
    .get(async function (req, res) {
      const { stock, like } = req.query;

      // Get the IP address and anonymise it
      const ip = req.ip || req.connection.remoteAddress;
      const ipHash = anonymizeIP(ip);

      try {
        // Handle single stock
        if (typeof stock === 'string') {
          const stockSymbol = stock.toUpperCase();

          // Add like if requested and not already liked
          if (like === 'true' && !hasLiked(stockSymbol, ipHash)) {
            addLike(stockSymbol, ipHash);
          }

          // Fetch stock data
          const stockData = await getStockPrice(stockSymbol);

          if (!stockData || stockData === 'Unknown symbol') {
            return res.json({ stockData: { error: 'Invalid symbol', likes: getLikes(stockSymbol) } });
          }

          return res.json({
            stockData: {
              stock: stockSymbol,
              price: stockData.latestPrice,
              likes: getLikes(stockSymbol)
            }
          });
        }

        // Handle two stocks
        if (Array.isArray(stock) && stock.length === 2) {
          const stock1 = stock[0].toUpperCase();
          const stock2 = stock[1].toUpperCase();

          // Add likes if requested and not already liked
          if (like === 'true') {
            if (!hasLiked(stock1, ipHash)) {
              addLike(stock1, ipHash);
            }
            if (!hasLiked(stock2, ipHash)) {
              addLike(stock2, ipHash);
            }
          }

          // Fetch both stock data
          const [stockData1, stockData2] = await Promise.all([
            getStockPrice(stock1),
            getStockPrice(stock2)
          ]);

          if (!stockData1 || stockData1 === 'Unknown symbol' || 
              !stockData2 || stockData2 === 'Unknown symbol') {
            return res.json({ error: 'Invalid symbol' });
          }

          const likes1 = getLikes(stock1);
          const likes2 = getLikes(stock2);

          return res.json({
            stockData: [
              {
                stock: stock1,
                price: stockData1.latestPrice,
                rel_likes: likes1 - likes2
              },
              {
                stock: stock2,
                price: stockData2.latestPrice,
                rel_likes: likes2 - likes1
              }
            ]
          });
        }

        // Invalid request
        return res.json({ error: 'Invalid request' });

      } catch (error) {
        console.error('Error:', error);
        return res.json({ error: 'Server error' });
      }
    });
};