// Import necessary dependencies and configure Chai for Hypertext Transfer Protocol (HTTP) requests.
const chaiHttp = require('chai-http');
const chai = require('chai');
const assert = chai.assert;
const server = require('../server');

chai.use(chaiHttp);
// Define variables to store identifications and passwords for test continuity.
suite('Functional Tests', function() {
  let testThreadId;
  let testReplyId;
  const testDeletePassword = 'testpass123';
  const wrongPassword = 'wrongpass';
  // Test creating a new thread and storing its identifications for subsequent tests.
  test('Creating a new thread: POST request to /api/threads/{board}', function(done) {
    chai.request(server)
      .post('/api/threads/test')
      .send({
        text: 'Test thread',
        delete_password: testDeletePassword
      })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        assert.property(res.body, '_id');
        assert.property(res.body, 'text');
        assert.property(res.body, 'created_on');
        assert.property(res.body, 'bumped_on');
        assert.property(res.body, 'replies');
        assert.isArray(res.body.replies);
        testThreadId = res.body._id;
        done();
      });
  });
  // Test viewing the 10 most recent threads, ensuring restricted data and reply count.
  test('Viewing the 10 most recent threads with 3 replies each: GET request to /api/threads/{board}', function(done) {
    chai.request(server)
      .get('/api/threads/test')
      .end(function(err, res) {
        assert.equal(res.status, 200);
        assert.isArray(res.body);
        assert.isAtMost(res.body.length, 10);
        if (res.body.length > 0) {
          assert.property(res.body[0], '_id');
          assert.property(res.body[0], 'text');
          assert.property(res.body[0], 'created_on');
          assert.property(res.body[0], 'bumped_on');
          assert.property(res.body[0], 'replies');
          assert.notProperty(res.body[0], 'reported');
          assert.notProperty(res.body[0], 'delete_password');
          assert.isAtMost(res.body[0].replies.length, 3);
        }
        done();
      });
  });
  // Test attempting to delete an existing thread with an incorrect password.
  test('Deleting a thread with the incorrect password: DELETE request to /api/threads/{board}', function(done) {
    chai.request(server)
      .delete('/api/threads/test')
      .send({
        thread_id: testThreadId,
        delete_password: wrongPassword
      })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        assert.equal(res.text, 'incorrect password');
        done();
      });
  });
  // Test successfully deleting a thread with the correct password (involves creating a new thread first).
  test('Deleting a thread with the correct password: DELETE request to /api/threads/{board}', function(done) {
    chai.request(server)
      .post('/api/threads/test')
      .send({
        text: 'Thread to delete',
        delete_password: testDeletePassword
      })
      .end(function(err, res) {
        const threadIdToDelete = res.body._id;

        chai.request(server)
          .delete('/api/threads/test')
          .send({
            thread_id: threadIdToDelete,
            delete_password: testDeletePassword
          })
          .end(function(err, res) {
            assert.equal(res.status, 200);
            assert.equal(res.text, 'success');
            done();
          });
      });
  });
  // Test reporting an existing thread to mark it as inappropriate.
  test('Reporting a thread: PUT request to /api/threads/{board}', function(done) {
    chai.request(server)
      .put('/api/threads/test')
      .send({
        thread_id: testThreadId
      })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        assert.equal(res.text, 'reported');
        done();
      });
  });
  // Test creating a new reply and capturing its identification for later deletion/reporting tests.
  test('Creating a new reply: POST request to /api/replies/{board}', function(done) {
    chai.request(server)
      .post('/api/replies/test')
      .send({
        thread_id: testThreadId,
        text: 'Test reply',
        delete_password: testDeletePassword
      })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        assert.property(res.body, '_id');
        assert.property(res.body, 'replies');
        assert.isArray(res.body.replies);
        assert.isAtLeast(res.body.replies.length, 1);
        testReplyId = res.body.replies[res.body.replies.length - 1]._id;
        done();
      });
  });
  // Test viewing a single thread, ensuring all replies are returned and sensitive fields are hidden.
  test('Viewing a single thread with all replies: GET request to /api/replies/{board}', function(done) {
    chai.request(server)
      .get('/api/replies/test')
      .query({ thread_id: testThreadId })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        assert.property(res.body, '_id');
        assert.property(res.body, 'text');
        assert.property(res.body, 'created_on');
        assert.property(res.body, 'bumped_on');
        assert.property(res.body, 'replies');
        assert.isArray(res.body.replies);
        assert.notProperty(res.body, 'reported');
        assert.notProperty(res.body, 'delete_password');
        if (res.body.replies.length > 0) {
          assert.notProperty(res.body.replies[0], 'reported');
          assert.notProperty(res.body.replies[0], 'delete_password');
        }
        done();
      });
  });
  // Test attempting to delete a reply with an incorrect password.
  test('Deleting a reply with the incorrect password: DELETE request to /api/replies/{board}', function(done) {
    chai.request(server)
      .delete('/api/replies/test')
      .send({
        thread_id: testThreadId,
        reply_id: testReplyId,
        delete_password: wrongPassword
      })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        assert.equal(res.text, 'incorrect password');
        done();
      });
  });
  // Test successfully deleting a reply with the correct password (should change the reply text to '[deleted]').
  test('Deleting a reply with the correct password: DELETE request to /api/replies/{board}', function(done) {
    chai.request(server)
      .delete('/api/replies/test')
      .send({
        thread_id: testThreadId,
        reply_id: testReplyId,
        delete_password: testDeletePassword
      })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        assert.equal(res.text, 'success');
        done();
      });
  });
  // Test reporting a reply to mark it as inappropriate (involves creating a new reply first).
  test('Reporting a reply: PUT request to /api/replies/{board}', function(done) {
    chai.request(server)
      .post('/api/replies/test')
      .send({
        thread_id: testThreadId,
        text: 'Reply to report',
        delete_password: testDeletePassword
      })
      .end(function(err, res) {
        const replyIdToReport = res.body.replies[res.body.replies.length - 1]._id;

        chai.request(server)
          .put('/api/replies/test')
          .send({
            thread_id: testThreadId,
            reply_id: replyIdToReport
          })
          .end(function(err, res) {
            assert.equal(res.status, 200);
            assert.equal(res.text, 'reported');
            done();
          });
      });
  });
});