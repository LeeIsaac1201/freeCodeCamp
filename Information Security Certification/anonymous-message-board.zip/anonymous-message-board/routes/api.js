'use strict';

const mongoose = require('mongoose'); // Import the Mongoose library.
// Connect to the MongoDB database using the connection string from environment variables.
mongoose.connect(process.env.DB, { useNewUrlParser: true, useUnifiedTopology: true });
// Define the Mongoose schema for a single reply within a thread.
const replySchema = new mongoose.Schema({
  text: { type: String, required: true },
  delete_password: { type: String, required: true },
  created_on: { type: Date, default: Date.now },
  reported: { type: Boolean, default: false }
});
// Define the Mongoose schema for a thread, which includes an array of replies.
const threadSchema = new mongoose.Schema({
  board: { type: String, required: true },
  text: { type: String, required: true },
  delete_password: { type: String, required: true },
  created_on: { type: Date, default: Date.now },
  bumped_on: { type: Date, default: Date.now },
  reported: { type: Boolean, default: false },
  replies: [replySchema]
});

const Thread = mongoose.model('Thread', threadSchema); // Create the Thread model for MongoDB interaction.

module.exports = function (app) {
  // Start routing for handling threads on a specific board.
  app.route('/api/threads/:board')
    // POST request to create a new thread in the specified board.
    .post(async (req, res) => {
      const { text, delete_password } = req.body;
      const board = req.params.board;

      const newThread = new Thread({
        board,
        text,
        delete_password
      });

      try {
        const savedThread = await newThread.save();
        res.json(savedThread);
      } catch (err) {
        res.json({ error: 'Error creating thread' });
      }
    })
    // GET request to retrieve 10 most recently bumped threads, showing only 3 newest replies.
    .get(async (req, res) => {
      const board = req.params.board;

      try {
        const threads = await Thread.find({ board })
          .sort({ bumped_on: -1 })
          .limit(10)
          .select('-delete_password -reported')
          .lean();

        threads.forEach(thread => {
          thread.replies = thread.replies
            .sort((a, b) => b.created_on - a.created_on)
            .slice(0, 3)
            .map(reply => ({
              _id: reply._id,
              text: reply.text,
              created_on: reply.created_on
            }));
        });

        res.json(threads);
      } catch (err) {
        res.json({ error: 'Error fetching threads' });
      }
    })
    // DELETE request to delete a thread by ID if the password matches.
    .delete(async (req, res) => {
      const { thread_id, delete_password } = req.body;

      try {
        const thread = await Thread.findById(thread_id);

        if (!thread) {
          return res.send('incorrect password');
        }

        if (thread.delete_password !== delete_password) {
          return res.send('incorrect password');
        }

        await Thread.findByIdAndDelete(thread_id);
        res.send('success');
      } catch (err) {
        res.send('incorrect password');
      }
    })
    // PUT request to report a thread by setting its 'reported' field to true.
    .put(async (req, res) => {
      const { thread_id } = req.body;

      try {
        await Thread.findByIdAndUpdate(thread_id, { reported: true });
        res.send('reported');
      } catch (err) {
        res.json({ error: 'Error reporting thread' });
      }
    });
  // Start routing for handling replies within threads on a specific board.
  app.route('/api/replies/:board')
    // POST request to add a new reply to a thread and update its bumped time.
    .post(async (req, res) => {
      const { text, delete_password, thread_id } = req.body;

      try {
        const thread = await Thread.findById(thread_id);

        if (!thread) {
          return res.json({ error: 'Thread not found' });
        }

        thread.replies.push({
          text,
          delete_password
        });
        thread.bumped_on = new Date();

        await thread.save();

        const updatedThread = await Thread.findById(thread_id);
        res.json(updatedThread);
      } catch (err) {
        res.json({ error: 'Error creating reply' });
      }
    })
    // GET request to fetch a single thread with all its replies (excluding sensitive fields).
    .get(async (req, res) => {
      const { thread_id } = req.query;

      try {
        const thread = await Thread.findById(thread_id)
          .select('-delete_password -reported')
          .lean();

        if (!thread) {
          return res.json({ error: 'Thread not found' });
        }

        thread.replies = thread.replies.map(reply => ({
          _id: reply._id,
          text: reply.text,
          created_on: reply.created_on
        }));

        res.json(thread);
      } catch (err) {
        res.json({ error: 'Error fetching thread' });
      }
    })
    // DELETE request to change a reply's text to '[deleted]' if the password is correct.
    .delete(async (req, res) => {
      const { thread_id, reply_id, delete_password } = req.body;

      try {
        const thread = await Thread.findById(thread_id);

        if (!thread) {
          return res.send('incorrect password');
        }

        const reply = thread.replies.id(reply_id);

        if (!reply) {
          return res.send('incorrect password');
        }

        if (reply.delete_password !== delete_password) {
          return res.send('incorrect password');
        }

        reply.text = '[deleted]';
        await thread.save();
        res.send('success');
      } catch (err) {
        res.send('incorrect password');
      }
    })
    // PUT request to report a reply by setting its 'reported' field to true.
    .put(async (req, res) => {
      const { thread_id, reply_id } = req.body;

      try {
        const thread = await Thread.findById(thread_id);

        if (!thread) {
          return res.json({ error: 'Thread not found' });
        }

        const reply = thread.replies.id(reply_id);

        if (!reply) {
          return res.json({ error: 'Reply not found' });
        }

        reply.reported = true;
        await thread.save();
        res.send('reported');
      } catch (err) {
        res.json({ error: 'Error reporting reply' });
      }
    });
};