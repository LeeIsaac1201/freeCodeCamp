/* eslint-env node */

/* Dependencies */
const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

/* Express Application Setup */
const app = express();

/* Middleware Configurwation */
// Cross-Origin Resource Sharing (CORS) for freeCodeCamp testing
app.use(cors({ optionsSuccessStatus: 200 }));

// Static file middleware (must be before any routes)
const staticPath = path.join(__dirname, "public");
console.log("Static root:", staticPath);
console.log(
  "index.html exists:",
  fs.existsSync(path.join(staticPath, "index.html")),
);
app.use(express.static(staticPath));

/* Api Routes */
// Timestamp API endpoint
app.get("/api/:date?", (req, res) => {
  const dateParam = req.params.date;
  let date;

  if (!dateParam) {
    date = new Date();
  } else if (/^\d+$/.test(dateParam)) {
    date = new Date(parseInt(dateParam, 10));
  } else {
    date = new Date(dateParam);
  }

  if (isNaN(date.getTime())) {
    return res.json({ error: "Invalid Date" });
  }

  return res.json({
    unix: date.getTime(),
    utc: date.toUTCString(),
  });
});

/* Error Handling */
// Error: 404 handler for unmatched routes
app.use((req, res) => {
  res.status(404).json({ error: "Not Found" });
});

/* Server Startup */
const port = process.env.PORT || 3000;
const host = process.env.IP || "0.0.0.0";
app.listen(port, host, () => {
  console.log(`App listening at http://${host}:${port}`);
});
